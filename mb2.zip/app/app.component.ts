import { Component, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { BlogCardsComponent } from './blog-cards/blog-cards.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less', '../assets/open-rainbow.less']
})
export class AppComponent implements AfterViewInit {
  title = 'myBiography';

  titleBg: string = "../assets/img/title-bg.png"

  @ViewChild('typing')
  typingH1!: ElementRef;

  @ViewChild('openscreen')
  openscreen!: ElementRef<HTMLDivElement>;



  constructor() {
    setTimeout(() => {
      this.openscreen.nativeElement.classList.add('is-loaded')
    }, 1000);
  }

  ngAfterViewInit(): void {
    const h1 = this.typingH1.nativeElement;
    // Support Space:
    h1.innerHTML = h1.innerHTML
    // .replace(/\S/g, "<span>$&</span>")
    // .replace(/\s/g, "<span>&nbsp;</span>")

    this.setChDelay(1.2)

    h1.addEventListener('animationend', (e: AnimationEvent) => {
      if (e.target === document.querySelector('h1 span:last-child')) {
        h1.classList.add('ended')
        this.setChDelay()

      }
    })
  }

  setChDelay(preDelay: number = 0, chstr: string = '') {
    document.querySelectorAll('span').forEach((span, index) => {
      let delay = preDelay + (index + 1) * 0.1
      // if (index === 9) delay += 0.3
      span.style.setProperty('--delay', `${delay}s`)
    })
  }
}
