import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'blog-cards',
  templateUrl: './blog-cards.component.html',
  styleUrls: ['./blog-cards.component.less']
})
export class BlogCardsComponent implements OnInit {

  blogs: any = [{
    title: 'qwe',
    contest: ''
  }, {
    title: '11qwe',
    contest: ''
  }, {
    title: '11qwe',
    contest: ''
  }, {
    title: '11qwe',
    contest: ''
  }]

  constructor() { }

  ngOnInit(): void {
  }

}
